package in.harsh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import in.harsh.bo.Student;
import in.harsh.service.IStudentService;
import in.harsh.service.StudentServiceImpl;

@SpringBootApplication
public class Assignment21Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Assignment21Application.class, args);
		IStudentService studentService = context.getBean(StudentServiceImpl.class);
		Student student = new Student(null, "Pankaj", 34, "Hyderabad");
		System.out.println(studentService.addStudent(student));
		((ConfigurableApplicationContext) context).close();
	}

}
