package in.harsh.dao;

import org.springframework.data.repository.CrudRepository;

import in.harsh.bo.Student;

public interface IStudentRepository extends CrudRepository<Student,Integer> {

}
