package main;

import java.util.ArrayDeque;
import java.util.Random;

public class ProducerConsumer {

	public static void main(String[] args) {
		ArrayDeque<Integer> queue = new ArrayDeque<Integer>();
		System.out.println(queue.toString());
		ProducerThread producerThread = new ProducerThread(queue);
		ConsumerThread consumerThread = new ConsumerThread(queue);
		consumerThread.start();
		producerThread.start();
	}
}

//Producer Thread
class ProducerThread extends Thread{
	
	ArrayDeque<Integer> queue;
	
	ProducerThread(ArrayDeque<Integer> queue){
		this.queue=queue;
	}
	
	@Override
	public void run() {
		synchronized (queue) {
			System.out.println("Producer Thread running");
			Random random = new Random();
			for (int i = 0; i < 10; i++) {
				queue.add(random.nextInt(100));
			}
			System.out.println("Producer Thread giving notification call");
			queue.notify();
		}
	}
}
//Consumer Thread
class ConsumerThread extends Thread{
	
	ArrayDeque<Integer> queue;
	
	ConsumerThread(ArrayDeque<Integer> queue){
		this.queue=queue;
	}
	
	@Override
	public void run() {
		synchronized (queue) {
			if (queue.isEmpty()) {
				try {
					System.out.println("Consumer Thread Waiting");
					queue.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println(queue.toString());
			int sum=0;
			for (Integer integer : queue) {
				sum+=integer;
			}
			System.out.println("Sum of queue is::"+sum);
		}
	}
}
