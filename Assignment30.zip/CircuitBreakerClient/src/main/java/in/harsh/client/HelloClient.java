package in.harsh.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("HELLO-SERVICE")
public interface HelloClient {
	
	@GetMapping("/hello/{name}")
	public String getMessage(@PathVariable String name);
}
