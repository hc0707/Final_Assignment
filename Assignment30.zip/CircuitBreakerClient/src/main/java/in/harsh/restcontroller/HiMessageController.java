package in.harsh.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import in.harsh.client.HelloClient;
import in.harsh.client.HelloClientBackup;

@RestController
public class HiMessageController {
	
	@Autowired
	private HelloClient client;
	@Autowired
	private HelloClientBackup bClient;
	
	@GetMapping("/hi/{name}")
	@HystrixCommand(fallbackMethod = "getMessageBackup")
	public String getMessage(@PathVariable String name) {
		String message = client.getMessage(name);
		return "Hii "+name+"! How are you?    "+message;
	}
	
	public String getMessageBackup(@PathVariable String name) {
		String message = bClient.getMessage(name);
		return "Hii "+name+"! How are you?    "+message;
	}
	
}
