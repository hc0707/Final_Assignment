package in.harsh.service;

import java.util.List;

import in.harsh.bo.Student;

public interface IStudentService {
	public List<Student> getStudent();
}
