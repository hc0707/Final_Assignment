package in.harsh.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.harsh.bo.Product;
import in.harsh.dao.IProductRepository;

@Service(value = "service")
public class ProductServiceImpl implements IProductService{
	
	@Autowired
	private IProductRepository productRepository;
	
	@Override
	public String addProduct(Product product) {
		Product savedProduct=null;
		if (productRepository != null) {
			savedProduct = productRepository.save(product);
		}
		return savedProduct!=null?"Product Registered with ID:: "+savedProduct.getId():"Product Registration Failed";
	}

	
	@Override
	public Product retrieveProduct(Integer id) {
		Product product=null;
		if (productRepository != null) {
			Optional<Product> optional = productRepository.findById(id);
			if (optional.isPresent()) {
				product=optional.get();
			}
		}
		return product;
	}

	@Override
	public String updateProduct(Product product) {
		Product savedProduct=null;
		if (productRepository != null) {
			savedProduct = productRepository.save(product);
		}
		return savedProduct!=null?"Product Updated with ID:: "+savedProduct.getId():"Student Registration Failed";
	}

	@Override
	public String deleteProduct(Integer id) {
		
		if (productRepository != null) {
			productRepository.deleteById(id);
		}
		return "Product deleted Successfully with id: "+id;
	}
	
}
