package in.harsh.service;

import in.harsh.bo.Product;

public interface IProductService {
	public String addProduct(Product product);
	public Product retrieveProduct(Integer id);
	public String updateProduct(Product product);
	public String deleteProduct(Integer id);
}
