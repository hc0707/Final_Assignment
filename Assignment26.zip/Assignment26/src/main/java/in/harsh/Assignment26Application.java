package in.harsh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment26Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment26Application.class, args);
	}

}
