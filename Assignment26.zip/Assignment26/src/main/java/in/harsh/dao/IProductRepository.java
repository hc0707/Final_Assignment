package in.harsh.dao;

import org.springframework.data.repository.CrudRepository;

import in.harsh.bo.Product;

public interface IProductRepository extends CrudRepository<Product,Integer> {

}
