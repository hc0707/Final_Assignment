package shapes;

public interface Shape {
	public float calculatePerimeter();
	public float calculateArea();
}
