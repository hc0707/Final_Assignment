package persistence;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jdbcutil.JdbcUtil;

public class Dao {

	private static Connection connection;
	private static PreparedStatement pstmt;

	public static ResultSet viewStudent() {

		String sqlQuery = "select id,name,age,address from studentdb";
		try {
			connection = JdbcUtil.getJdbcConnection();
			if (connection != null) {
				pstmt = connection.prepareStatement(sqlQuery);

			}
			if (pstmt != null) {
				ResultSet rs = pstmt.executeQuery();
				return rs;
			}
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}
}
