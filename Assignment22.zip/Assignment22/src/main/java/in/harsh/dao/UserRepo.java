package in.harsh.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.harsh.bo.User;


public interface UserRepo extends JpaRepository<User, Long> {

}