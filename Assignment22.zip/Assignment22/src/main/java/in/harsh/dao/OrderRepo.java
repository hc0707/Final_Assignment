package in.harsh.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.harsh.bo.Order;
import in.harsh.bo.User;



public interface OrderRepo extends JpaRepository<Order, Long> {
	public List<Order> findByUser(User user);

}