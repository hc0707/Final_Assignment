package in.harsh;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import in.harsh.bo.Order;
import in.harsh.bo.User;
import in.harsh.dao.OrderRepo;
import in.harsh.dao.UserRepo;

@SpringBootApplication
public class Assignment21Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Assignment21Application.class, args);
		UserRepo userRepository = context.getBean(UserRepo.class);
		OrderRepo orderRepository = context.getBean(OrderRepo.class);

		User user = userRepository.getById((long) 5);
		System.out.println("user " + user);
		System.out.println("Orders " + user.getOrders());

		System.out.println("----------------------------");
		List<Order> user2 = orderRepository.findByUser(user);
		System.out.println("order " + user2.toString());
		
		((ConfigurableApplicationContext) context).close();
	}

}
