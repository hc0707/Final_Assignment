package in.harsh.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.harsh.bo.Student;
import in.harsh.service.IStudentService;

@RestController
@RequestMapping("/api")
public class StudentRestController {
	
	@Autowired
	IStudentService service;
	
	@PostMapping("/insert")
	public ResponseEntity<String> addStudent(@RequestBody Student student){
		String message=null;
		if (service != null) {
			message = service.addStudent(student);
		}
		return new ResponseEntity<String>(message, HttpStatus.OK);
	}
}
