package in.harsh.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.harsh.bo.Student;
import in.harsh.dao.IStudentRepository;

@Service(value = "service")
public class StudentServiceImpl implements IStudentService{
	
	@Autowired
	private IStudentRepository studentRepository;
	
	@Override
	public String addStudent(Student student) {
		Student savedStudent=null;
		if (studentRepository != null) {
			savedStudent = studentRepository.save(student);
		}
		return savedStudent!=null?"Student Registered with ID:: "+savedStudent.getId():"Student Registration Failed";
	}
	
}
