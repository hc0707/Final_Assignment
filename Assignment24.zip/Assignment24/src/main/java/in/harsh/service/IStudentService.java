package in.harsh.service;

import in.harsh.bo.Student;

public interface IStudentService {
	public String addStudent(Student student);
}
