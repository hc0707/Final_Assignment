package main;

interface Banking{
	/*
	 1-An interface is a service requirement specification which is represented in 
	   java as a class with all methods as abstract(100% abstraction).
	 2-It can not be instantiated and must be implemented by a class which is either
	   concrete or abstract.We can not extend an interface.
	 3-This is an abstract method which has no body and no implementation at all
	 */
	public abstract void withdraw(double amount);
	/*
	 4-By default methods in interface are treated as abstract if we don't use abstract 
	   keyword in the method signature. 
	 */
	public void deposit(double amount);
	/*
	 5-After JDK 8 and later versions we are allowed to have concrete methods also in an 
	   interface but they must be either default or private.
	 */
	default void getBalance() {
		System.out.println("Bance: Rs.50000");
	}
	private void getMessage() {
		System.out.println("Welcome to Bank");
	}
}

abstract class Customer{
	/*
	 1- An abstract class contains abstract methods or concrete methods or both.
	 2- It can have abstraction from (0-100)%
	 3- A class having no abstract method can still be declared as abstract.
	    However, if a class contains at least one abstract method then it must compulsorily
	    be declared as abstract.
	 4- Abstract class like interface can not be instantiated.   
	 5- Abstract class should be extended not implemented.
	 */
	public abstract String getCustomerName();
	public void createCustomerAccount() {
		System.out.println("Customer Account Created");
	}
}