package main;

import persistence.JDBCConnection;

public class Test {

	public static void main(String[] args) {
		JDBCConnection.getData();
	}
}

