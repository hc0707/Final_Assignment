package in.harsh.service;

import in.harsh.bo.Product;

public interface IProductService {
	 public Iterable<Product> getProducts(Integer pageNo, Integer size);
}
