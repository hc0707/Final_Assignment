package in.harsh.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import in.harsh.bo.Product;
import in.harsh.dao.IProductRepository;

@Service(value = "service")
public class ProductServiceImpl implements IProductService{
	
	@Autowired
	private IProductRepository productRepository;

	@Override
	public Iterable<Product> getProducts(Integer pageNo, Integer size) {
		Pageable pageable = PageRequest.of(pageNo, size);
		   Page<Product> all = productRepository.findAll(pageable);
		return all.getContent();
	}
	
	
}
