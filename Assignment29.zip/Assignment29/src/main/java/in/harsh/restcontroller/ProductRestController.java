package in.harsh.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.harsh.bo.Product;
import in.harsh.service.IProductService;

@RestController
@RequestMapping("/api")
public class ProductRestController {
	
	@Autowired
	IProductService service;
	
	@GetMapping("/get/{pageNo}/{size}")
	public ResponseEntity<List<Product>> getProducts(@PathVariable Integer pageNo,@PathVariable Integer size){
		
		   Iterable<Product> students = service.getProducts(pageNo, size);
		
		return new ResponseEntity<List<Product>>((List<Product>) students,HttpStatus.OK);
	}
	
	
}
