package in.harsh.dao;

import org.springframework.data.repository.PagingAndSortingRepository;

import in.harsh.bo.Product;

public interface IProductRepository extends PagingAndSortingRepository<Product,Integer> {

}
