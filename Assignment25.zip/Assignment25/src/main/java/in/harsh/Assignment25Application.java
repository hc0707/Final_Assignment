package in.harsh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import in.harsh.service.ServiceClass;

@SpringBootApplication
public class Assignment25Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Assignment25Application.class, args);
		ServiceClass service = context.getBean(ServiceClass.class);
		service.createUser("harsh", "harsh@gmail.com");
		service.deleteUser("harsh");
		((ConfigurableApplicationContext) context).close();
	}

}
