package main;

import java.util.Scanner;

public class Bank {

	public static void main(String[] args) {
		double balance = 0;
		Scanner scanner = new Scanner(System.in);
		while (true) {
			System.out.println("\n==============Welcome to Bank===============");
			System.out.println("Press 1: Check you account balance");
			System.out.println("Press 2: Deposit money in your account");
			System.out.println("Press 3: Withdraw money from your account");
			System.out.println("Press 4: Exit");
			int input = scanner.nextInt();
			switch (input) {
				case 1:
					System.out.println("Your Balance is: Rs." + balance);
					break;
				case 2:
					System.out.println("Enter the amount to deposit");
					double deposit = scanner.nextDouble();
					balance += deposit;
					System.out.println("Amout of Rs." + deposit + " deposited successfully");
					break;
				case 3:
					System.out.println("Enter the amount to deposit");
					double withdraw = scanner.nextDouble();
					balance -= withdraw;
					System.out.println("Amout of Rs." + withdraw + " deposited successfully");
					break;
				case 4:
					scanner.close();
					System.exit(0);
				default:
					System.out.println("Please enter a valid input");
					break;
			}
		}
	}
}
