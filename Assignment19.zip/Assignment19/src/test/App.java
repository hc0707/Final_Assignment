package test;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Student;
import util.HibernateUtil;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = HibernateUtil.getSession();
		Transaction transaction = null;
		Integer id = null;

		// Reading Data
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Student Name");
		String name = scanner.next();
		System.out.println("Enter Student Age");
		int age = scanner.nextInt();
		System.out.println("Enter Student Address");
		String address = scanner.next();
		scanner.close();

		// Saving Data
		Student student = new Student();
		student.setName(name);
		student.setAge(age);
		student.setAddress(address);
		try {
			if (session != null) {
				transaction = session.beginTransaction();
				if (transaction != null)
					id = (int) session.save(student);
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (id != null) {
				transaction.commit();
				//Retrieving the inserted data and printing it
				System.out.println(session.get(Student.class, id));
			} else
				transaction.rollback();

			HibernateUtil.closeSession();
			HibernateUtil.closeSessionFactory();

		}
	}
}
