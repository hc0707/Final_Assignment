package in.harsh.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.harsh.bo.Student;
import in.harsh.service.IStudentService;

@RestController
@RequestMapping("/api")
public class StudentRestController {
	
	@Autowired
	IStudentService service;
	
	@GetMapping("/get")
	public ResponseEntity<List<Student>> getStudent(){
		List<Student> studentList=null;
		if (service != null) {
			studentList = service.getStudent();
		}
		return new ResponseEntity<List<Student>>(studentList, HttpStatus.OK);
	}
}
