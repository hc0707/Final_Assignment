package in.harsh.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import in.harsh.model.Employee;
import in.harsh.service.IEmployeeService;

@Controller
public class AppController {
	
	@Autowired
	private IEmployeeService employeeService;
	
	@GetMapping("/")
	public String homePage() {
		return "Home";
	}
	
	@GetMapping("/login")
	public String loginPage() {
		return "Login";
	}
	
	@GetMapping("/register")
	public String registrationPage() {
		return "Registration";
	}
	
	@GetMapping("/logout")
	public String doLogout(HttpSession session) {
		session.removeAttribute("employeelog");
		return "redirect:/";
	}
	
	@PostMapping("/register")
	public String registerEmployee(@ModelAttribute("employee")Employee employee) {
		if (employeeService != null) {
			if (employeeService.registerEmployee(employee) != null) {
				return "redirect:/";
			}
		}
		return "Registration";
	}
	
	@PostMapping("/login")
	public String loginEmployee(@ModelAttribute("employee")Employee employee, HttpSession session) {
		if (employeeService != null) {
			Employee loginEmployee = employeeService.loginEmployee(employee);
			if (loginEmployee!=null) {
				session.setAttribute("employeelog", loginEmployee);
				return "redirect:/";
			}
		}
		return "Login";
	}
	
	
	
}
