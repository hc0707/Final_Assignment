package in.harsh.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.harsh.dao.IEmployeeRepo;
import in.harsh.model.Employee;

@Service
public class EmployeeServiceImpl implements IEmployeeService {
	
	@Autowired
	private IEmployeeRepo employeeRepo;
	
	@Override
	public Employee registerEmployee(Employee employee) {
		if (employeeRepo != null) {
			return employeeRepo.save(employee);
		}
		return null;
	}

	@Override
	public Employee loginEmployee(Employee employee) {
		if (employeeRepo != null) {
			List<Employee> list = employeeRepo.findByEmailAndPassword(employee.getEmail(), employee.getPassword());
			if (!list.isEmpty()) {
				return list.get(0);
			}
			return null;
		}
		
		return null;
	}

}
