package in.harsh.service;

import in.harsh.model.Employee;

public interface IEmployeeService {
	public Employee registerEmployee(Employee employee);
	public Employee loginEmployee(Employee employee);
}
